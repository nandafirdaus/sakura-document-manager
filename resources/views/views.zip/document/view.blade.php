@extends('app')

@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">Lihat Dokumen</div>
				<div class="panel-body">
					@if (count($errors) > 0)
						<div class="alert alert-danger">
							<strong>Whoops!</strong> Ada yang salah dengan input yang anda masukkan.<br><br>
							<ul>
								@foreach ($errors->all() as $error)
									<li>{{ $error }}</li>
								@endforeach
							</ul>
						</div>
					@endif

					<form class="form-horizontal" role="form">
						<input type="hidden" name="_token" value="{{ csrf_token() }}">

						<input type="hidden" name="id" value="{{ $document->id }}">
						<div class="form-group">
							<label class="col-md-4 control-label">Issued:</label>
							<div class="col-md-6">
								<p class="form-control-static">{{ date('d-m-Y', strtotime($document->issued)) }}</p>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Expired:</label>
							<div class="col-md-6">
								<p class="form-control-static">{{ date('d-m-Y', strtotime($document->expired)) }}</p>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Tipe Dokumen:</label>
							<div class="col-md-6">
								<p class="form-control-static">{{ $document->documentType->name }}</p>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Nomor Dokumen:</label>
							<div class="col-md-6">
								<p class="form-control-static">{{ $document->doc_number }}</p>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Download dokumen:</label>
							<div class="col-md-6">
								<a class="btn btn-default btn-sm" href="{{ url($document->file_url) }}" target="_blank" role="button">Download</a>
							</div>
						</div>

						<div class="form-group">
							<div class="col-md-6 col-md-offset-4">
								@if($prev == '')
								<a class="btn btn-primary" href="{{ url('kitas/' . $document->kitas_id . '/view') }}" role="button">Kembali</a>
								@else
									<a class="btn btn-primary" href="{{ url('expired/imta') }}" role="button">Kembali</a>
								@endif
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
